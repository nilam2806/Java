/**
 * 
 */
/**
 * 
 */
module javalearning {
}