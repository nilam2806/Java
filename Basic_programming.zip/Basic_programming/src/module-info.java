/**
 * 
 */
/**
 * 
 */
module Basic_programming {
	requires java.desktop;
}